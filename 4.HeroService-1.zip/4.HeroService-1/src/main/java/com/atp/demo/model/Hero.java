package com.atp.demo.model;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Hero {
	
	public Hero(Long heroId, String heroName, String heroFee) {
		super();
		this.heroId = heroId;
		this.heroName = heroName;
		this.heroFee = heroFee;
	}
	private Long heroId;
	private String heroName;
	private String heroFee;
	private List<Movie> movieList;
	public Long getHeroId() {
		return heroId;
	}
	public void setHeroId(Long heroId) {
		this.heroId = heroId;
	}
	public String getHeroName() {
		return heroName;
	}
	public void setHeroName(String heroName) {
		this.heroName = heroName;
	}
	public String getHeroFee() {
		return heroFee;
	}
	public void setHeroFee(String heroFee) {
		this.heroFee = heroFee;
	}
	public List<Movie> getMovieList() {
		return movieList;
	}
	public void setMovieList(List<Movie> movieList) {
		this.movieList = movieList;
	}
	public Hero(Long heroId, String heroName, String heroFee, List<Movie> movieList) {
		super();
		this.heroId = heroId;
		this.heroName = heroName;
		this.heroFee = heroFee;
		this.movieList = movieList;
	}
	public Hero() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
