package com.atp.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/*@Data
@NoArgsConstructor
@AllArgsConstructor*/
public class Movie {

	
	private Long movieId;
	private String movieName;
	private String movieYear;
	private Long heroId;
	
	
	public Movie(Long movieId, String movieName, String movieYear, Long heroId) {
		super();
		this.movieId = movieId;
		this.movieName = movieName;
		this.movieYear = movieYear;
		this.heroId = heroId;
	}
	public Movie() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Long getMovieId() {
		return movieId;
	}
	public void setMovieId(Long movieId) {
		this.movieId = movieId;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieYear() {
		return movieYear;
	}
	public void setMovieYear(String movieYear) {
		this.movieYear = movieYear;
	}
	public Long getHeroId() {
		return heroId;
	}
	public void setHeroId(Long heroId) {
		this.heroId = heroId;
	}
}
