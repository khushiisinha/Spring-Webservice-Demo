package com.atp.demo.service;

import com.atp.demo.model.Hero;

public interface HeroService {
	
	public Hero getHeroById(Long heroId);



}
