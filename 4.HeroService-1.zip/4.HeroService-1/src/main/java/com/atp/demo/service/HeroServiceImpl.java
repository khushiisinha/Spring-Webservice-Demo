package com.atp.demo.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.atp.demo.model.Hero;

@Service
public class HeroServiceImpl implements HeroService{

	List<Hero> list=Arrays.asList(new Hero(1L,"Amir Khan","3CR"),
			new Hero(2L,"Salman Khan","6CR"),new Hero(3L,"Shahrukh Khan","9CR"));

	@Override
	public Hero getHeroById(Long heroId) {

		return list.stream().filter(hero->hero.getHeroId()==heroId).findAny().orElse(null);
		
		
	}
	

	
	
}



