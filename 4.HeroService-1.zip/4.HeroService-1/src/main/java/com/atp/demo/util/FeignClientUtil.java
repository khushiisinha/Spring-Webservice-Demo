package com.atp.demo.util;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.atp.demo.model.Movie;

@FeignClient(value="Feign-Demo",url="http://localhost:9002/movie/")
public class FeignClientUtil {
	
	@GetMapping("/hero/{heroId}")
    public List<Movie> getAllMoviesByHeroId(@PathVariable Long id);
}

