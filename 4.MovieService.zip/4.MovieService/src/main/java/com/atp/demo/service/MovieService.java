package com.atp.demo.service;

import java.util.List;

import com.atp.demo.model.Movie;

public interface MovieService {
	
	public List<Movie> getAllMoviewsByHeroId(Long heroId);

}
