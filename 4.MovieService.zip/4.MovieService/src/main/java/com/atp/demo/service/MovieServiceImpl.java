package com.atp.demo.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.atp.demo.model.Movie;

@Service
public class MovieServiceImpl implements MovieService {
	
	List<Movie> list=Arrays.asList(new Movie(1L,"Gajni","2008",1L),
			new Movie(2L,"Fanaa","2009",1L),
			new Movie(3L,"Tiger","2010",2L),
			new Movie(4L,"Kick","2011",2L),
			new Movie(5L,"Veer Zara","2004",3L),
			new Movie(6L,"My Name is Khan","2010",3L));

	@Override
	public List<Movie> getAllMoviewsByHeroId(Long heroId) {
		return list.stream().filter(movie->movie.getHeroId().equals(heroId)).collect(Collectors.toList());
	}

}

